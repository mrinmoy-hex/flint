from lox.ast.expr import *
from lox.token import Token
from lox.token_types import TokenType

class AstPrinter(ExprVisitor):
    
    def print(self, expr):
        # start visitor process
        return expr.accept(self)
    
    
    def visit_binary(self, binary):
        # format a binary expression
        return self.parenthesize(binary.operator, binary.left, binary.right)
    
    def visit_grouping(self, expr):
        # Format a grouping expression
        return self.parenthesize("group", expr.expression)
    
    def visit_literal(self, literal):
        # handle literal values
        if literal.value is None:
            return "nil"
        return str(literal.value)
    
    def visit_unary(self, expr):
        # Format a unary expression
        return self.parenthesize(expr.operator, expr.right)
    
    
    def parenthesize(self, name, *exprs):
        # helper method to format expressions
        parts = [name]
        for expr in exprs:
            parts.append(self.print(expr))
        return f"({''.join(parts)})"
    
    
# Constructing the expression
expression = Expr.Binary(
    Expr.Unary(
        Token(TokenType.MINUS, "-", None, 1),
        Expr.Literal(123)
    ),
    Token(TokenType.STAR, "*", None, 1),
    Expr.Grouping(
        Expr.Literal(45.67)
    )
)

# Printing the expression
printer = AstPrinter()
print(printer.print(expression))
    
    