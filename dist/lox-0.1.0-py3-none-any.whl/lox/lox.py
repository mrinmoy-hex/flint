import sys

class Lox:

    @staticmethod
    def main() -> None:
        print(sys.argv)

if __name__ == '__main__':
    Lox.main()