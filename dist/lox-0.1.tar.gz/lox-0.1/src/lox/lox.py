import sys


class Lox:
    
    
    
    
    
    
    
    
    
    @staticmethod
    def main():    
        print(sys.argv)
        
        
        
        
        
if __name__ == "__main__":
    Lox.main()